void integrate_rk2(double* y, int n, double t, double dt, double* yn, double* mass, void (*f)(double*, double, double*, double*));
