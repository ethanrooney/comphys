

void solve_linsys(double* a, int n, double* b, double* x);
